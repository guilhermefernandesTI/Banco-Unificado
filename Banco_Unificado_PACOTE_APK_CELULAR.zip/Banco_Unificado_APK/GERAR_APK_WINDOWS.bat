@echo off
setlocal
cd /d "%~dp0"
echo [1/4] Instalando dependencias...
call npm install
if errorlevel 1 goto erro
echo [2/4] Criando projeto Android...
if not exist android call npx cap add android
if errorlevel 1 goto erro
echo [3/4] Sincronizando arquivos...
call npx cap sync android
if errorlevel 1 goto erro
echo [4/4] Abrindo Android Studio...
call npx cap open android
echo No Android Studio: Build ^> Build Bundle(s) / APK(s) ^> Build APK(s).
goto fim
:erro
echo Ocorreu um erro. Verifique se Node.js e Android Studio/SDK estao instalados.
:fim
pause
