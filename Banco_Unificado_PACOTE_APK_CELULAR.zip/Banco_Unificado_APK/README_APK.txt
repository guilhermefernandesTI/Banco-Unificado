BANCO UNIFICADO - PREPARADO PARA APK ANDROID

Este pacote inclui a aplicação web e a estrutura Capacitor para empacotá-la como Android.

REQUISITOS:
- Node.js (LTS)
- Android Studio
- Android SDK instalado/configurado pelo Android Studio

PASSOS (Windows):
1. Extraia esta pasta para um local simples, por exemplo C:\BancoUnificado.
2. Instale Node.js LTS e Android Studio.
3. Execute GERAR_APK_WINDOWS.bat.
4. Quando o Android Studio abrir, aguarde sincronização/Gradle.
5. No Android Studio, use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK debug normalmente fica em android\app\build\outputs\apk\debug\app-debug.apk.

DADOS:
A aplicação usa localStorage para persistência local. Dados ficam no dispositivo/app e
não são sincronizados automaticamente entre dispositivos. Exportar/importar JSON
continua disponível na interface.

ID Android: com.bancounificado.app
