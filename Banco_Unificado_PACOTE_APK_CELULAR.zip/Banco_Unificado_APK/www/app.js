const storageKey = "banco-unificado-data-v3";
const oldStorageKey = "banco-unificado-data-v1";

const todayIso = () => new Date().toISOString().slice(0, 10);

const initialData = createInitialData();
let data = loadData();

const elements = {
  bankForm: document.querySelector("#bankForm"),
  bankName: document.querySelector("#bankName"),
  bankType: document.querySelector("#bankType"),
  bankCurrency: document.querySelector("#bankCurrency"),
  bankInitialBalance: document.querySelector("#bankInitialBalance"),
  bankColor: document.querySelector("#bankColor"),
  bankColorOptions: document.querySelectorAll("[data-color]"),
  transactionForm: document.querySelector("#transactionForm"),
  transactionFormTitle: document.querySelector("#transactionFormTitle"),
  transactionId: document.querySelector("#transactionId"),
  transactionType: document.querySelector("#transactionType"),
  transactionStatusField: document.querySelector("#transactionStatusField"),
  transactionStatus: document.querySelector("#transactionStatus"),
  transactionDescription: document.querySelector("#transactionDescription"),
  transactionBank: document.querySelector("#transactionBank"),
  transactionAmount: document.querySelector("#transactionAmount"),
  transactionDate: document.querySelector("#transactionDate"),
  transactionCategory: document.querySelector("#transactionCategory"),
  transactionPaymentField: document.querySelector("#transactionPaymentField"),
  transactionPaymentMethod: document.querySelector("#transactionPaymentMethod"),
  transactionNote: document.querySelector("#transactionNote"),
  saveTransactionButton: document.querySelector("#saveTransactionButton"),
  cancelEditButton: document.querySelector("#cancelEditButton"),
  invoicePaymentForm: document.querySelector("#invoicePaymentForm"),
  invoiceCardBank: document.querySelector("#invoiceCardBank"),
  invoicePayingBank: document.querySelector("#invoicePayingBank"),
  invoiceAmount: document.querySelector("#invoiceAmount"),
  invoiceDate: document.querySelector("#invoiceDate"),
  invoiceStatus: document.querySelector("#invoiceStatus"),
  invoicePendingTotal: document.querySelector("#invoicePendingTotal"),
  fillInvoiceTotalButton: document.querySelector("#fillInvoiceTotalButton"),
  transferForm: document.querySelector("#transferForm"),
  transferFromBank: document.querySelector("#transferFromBank"),
  transferToBank: document.querySelector("#transferToBank"),
  transferAmount: document.querySelector("#transferAmount"),
  transferDate: document.querySelector("#transferDate"),
  budgetForm: document.querySelector("#budgetForm"),
  budgetCategory: document.querySelector("#budgetCategory"),
  budgetAmount: document.querySelector("#budgetAmount"),
  totalBRL: document.querySelector("#totalBRL"),
  totalEUR: document.querySelector("#totalEUR"),
  monthIncome: document.querySelector("#monthIncome"),
  monthExpense: document.querySelector("#monthExpense"),
  pendingTotal: document.querySelector("#pendingTotal"),
  accountsHint: document.querySelector("#accountsHint"),
  accountsList: document.querySelector("#accountsList"),
  categoryBars: document.querySelector("#categoryBars"),
  bankBars: document.querySelector("#bankBars"),
  paymentBars: document.querySelector("#paymentBars"),
  budgetList: document.querySelector("#budgetList"),
  transactionRows: document.querySelector("#transactionRows"),
  transactionCount: document.querySelector("#transactionCount"),
  emptyStateTemplate: document.querySelector("#emptyStateTemplate"),
  screenTitle: document.querySelector("#screenTitle"),
  searchInput: document.querySelector("#searchInput"),
  filterBank: document.querySelector("#filterBank"),
  filterType: document.querySelector("#filterType"),
  filterPayment: document.querySelector("#filterPayment"),
  filterStatus: document.querySelector("#filterStatus"),
  filterPeriod: document.querySelector("#filterPeriod"),
  exportButton: document.querySelector("#exportButton"),
  importInput: document.querySelector("#importInput"),
  tabButtons: document.querySelectorAll("[data-target]"),
  screens: document.querySelectorAll("[data-screen]"),
  typeButtons: document.querySelectorAll("[data-type-choice]"),
  actionButtons: document.querySelectorAll("[data-action-target]"),
  actionPanels: document.querySelectorAll("[data-action-panel]"),
};

elements.transactionDate.value = todayIso();
elements.transactionStatus.value = "pending";
elements.invoiceDate.value = todayIso();
elements.transferDate.value = todayIso();

const screenTitles = {
  home: "Inicio",
  accounts: "Contas",
  new: "Lancar",
  budgets: "Orcamento",
  history: "Historico",
};

elements.bankForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const bank = {
    id: crypto.randomUUID(),
    name: elements.bankName.value.trim(),
    type: elements.bankType.value,
    currency: elements.bankCurrency.value || "BRL",
    initialBalance: Number(elements.bankInitialBalance.value || 0),
    color: elements.bankColor.value,
  };

  if (!bank.name) return;

  data.banks.push(bank);
  saveData();
  elements.bankForm.reset();
  setSelectedBankColor("#1864ab");
  render();
});

elements.bankColorOptions.forEach((button) => {
  button.addEventListener("click", () => {
    setSelectedBankColor(button.dataset.color);
  });
});

elements.transactionForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!data.banks.length) {
    alert("Cadastre uma conta antes de registrar lancamentos.");
    return;
  }

  const amount = Number(elements.transactionAmount.value);
  if (!Number.isFinite(amount) || amount <= 0) return;

  const transaction = {
    id: elements.transactionId.value || crypto.randomUUID(),
    type: elements.transactionType.value,
    status: elements.transactionType.value === "income" ? "paid" : elements.transactionStatus.value,
    bankId: elements.transactionBank.value,
    description: elements.transactionDescription.value.trim(),
    category: elements.transactionCategory.value,
    paymentMethod: elements.transactionType.value === "income" ? "Pix" : elements.transactionPaymentMethod.value,
    amount,
    date: elements.transactionDate.value,
    note: elements.transactionNote.value.trim(),
  };

  const existingIndex = data.transactions.findIndex((item) => item.id === transaction.id);
  if (existingIndex >= 0) {
    data.transactions[existingIndex] = transaction;
  } else {
    data.transactions.push(transaction);
  }

  saveData();
  resetTransactionForm();
  render();
});

elements.budgetForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const amount = Number(elements.budgetAmount.value);
  if (!Number.isFinite(amount) || amount <= 0) return;

  data.budgets[elements.budgetCategory.value] = amount;
  saveData();
  elements.budgetForm.reset();
  render();
});

elements.invoicePaymentForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (data.banks.length < 2) {
    alert("Cadastre pelo menos duas contas: o cartao e a conta que vai pagar.");
    return;
  }

  const cardBankId = elements.invoiceCardBank.value;
  const payingBankId = elements.invoicePayingBank.value;
  const amount = Number(elements.invoiceAmount.value);
  const pendingTotal = getInvoicePendingTotal(cardBankId);

  if (cardBankId === payingBankId) {
    alert("Escolha bancos diferentes para o cartao e para a conta que vai pagar.");
    return;
  }
  const invoiceCardAccount = data.banks.find((bank) => bank.id === cardBankId);
  const invoicePayingAccount = data.banks.find((bank) => bank.id === payingBankId);
  if (invoiceCardAccount && invoicePayingAccount && invoiceCardAccount.currency !== invoicePayingAccount.currency) {
    alert("As contas precisam usar a mesma moeda para pagar uma fatura. Conversao entre moedas nao esta habilitada.");
    return;
  }

  if (!Number.isFinite(amount) || amount <= 0) return;

  if (pendingTotal <= 0) {
    alert("Este cartao nao tem fatura pendente.");
    return;
  }

  if (amount > pendingTotal) {
    alert(`O valor maximo para esta fatura e ${formatCurrency(pendingTotal, getBankCurrency(cardBankId))}.`);
    elements.invoiceAmount.value = pendingTotal.toFixed(2);
    return;
  }

  const cardBank = data.banks.find((bank) => bank.id === cardBankId);
  const payingBank = data.banks.find((bank) => bank.id === payingBankId);
  const groupId = crypto.randomUUID();
  const status = elements.invoiceStatus.value;
  const date = elements.invoiceDate.value;

  applyInvoicePayment(cardBankId, amount, status, groupId);

  data.transactions.push(
    {
      id: crypto.randomUUID(),
      groupId,
      type: "expense",
      status,
      bankId: payingBankId,
      description: `Pagamento fatura ${cardBank?.name || "cartao"}`,
      category: "Pagamento de fatura",
      paymentMethod: "Transferencia",
      amount,
      date,
      note: `Conta pagadora: ${payingBank?.name || "Nao informada"}`,
    },
    {
      id: crypto.randomUUID(),
      groupId,
      type: "income",
      status,
      bankId: cardBankId,
      description: `Baixa fatura ${cardBank?.name || "cartao"}`,
      category: "Pagamento de fatura",
      paymentMethod: "Transferencia",
      amount,
      date,
      note: `Fatura paga por ${payingBank?.name || "Nao informado"}`,
    }
  );

  saveData();
  resetInvoicePaymentForm();
  render();
  showScreen("history");
});

elements.fillInvoiceTotalButton.addEventListener("click", () => {
  const pendingTotal = getInvoicePendingTotal(elements.invoiceCardBank.value);
  elements.invoiceAmount.value = pendingTotal > 0 ? pendingTotal.toFixed(2) : "";
});

elements.invoiceCardBank.addEventListener("change", updateInvoicePendingTotal);

elements.transferForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const fromBankId = elements.transferFromBank.value;
  const toBankId = elements.transferToBank.value;
  const amount = Number(elements.transferAmount.value);

  if (fromBankId === toBankId) {
    alert("Escolha bancos diferentes para transferir.");
    return;
  }

  if (!Number.isFinite(amount) || amount <= 0) return;

  const fromBank = data.banks.find((bank) => bank.id === fromBankId);
  const toBank = data.banks.find((bank) => bank.id === toBankId);
  if (fromBank && toBank && fromBank.currency !== toBank.currency) {
    alert("A transferencia precisa ser entre contas da mesma moeda. Para enviar entre EUR e BRL, sera necessario registrar a conversao separadamente.");
    return;
  }
  const groupId = crypto.randomUUID();
  const date = elements.transferDate.value;

  data.transactions.push(
    {
      id: crypto.randomUUID(),
      groupId,
      type: "expense",
      status: "paid",
      bankId: fromBankId,
      description: `Transferencia para ${toBank?.name || "banco"}`,
      category: "Transferencia",
      paymentMethod: "Transferencia",
      amount,
      date,
      note: `Saiu de ${fromBank?.name || "Nao informado"}`,
    },
    {
      id: crypto.randomUUID(),
      groupId,
      type: "income",
      status: "paid",
      bankId: toBankId,
      description: `Transferencia de ${fromBank?.name || "banco"}`,
      category: "Transferencia",
      paymentMethod: "Transferencia",
      amount,
      date,
      note: `Entrou em ${toBank?.name || "Nao informado"}`,
    }
  );

  saveData();
  resetTransferForm();
  render();
  showScreen("history");
});

elements.cancelEditButton.addEventListener("click", resetTransactionForm);
elements.typeButtons.forEach((button) => {
  button.addEventListener("click", () => {
    elements.transactionType.value = button.dataset.typeChoice;
    syncTransactionTypeButtons();
    syncTransactionFields();
  });
});
elements.transactionPaymentMethod.addEventListener("change", syncTransactionFields);
elements.tabButtons.forEach((button) => {
  button.addEventListener("click", () => showScreen(button.dataset.target));
});
elements.actionButtons.forEach((button) => {
  button.addEventListener("click", () => showActionPanel(button.dataset.actionTarget));
});
elements.searchInput.addEventListener("input", render);
elements.filterBank.addEventListener("change", render);
elements.filterType.addEventListener("change", render);
elements.filterPayment.addEventListener("change", render);
elements.filterStatus.addEventListener("change", render);
elements.filterPeriod.addEventListener("change", render);

elements.exportButton.addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `banco-unificado-backup-${todayIso()}.json`;
  link.click();
  URL.revokeObjectURL(link.href);
});

elements.importInput.addEventListener("change", async (event) => {
  const [file] = event.target.files;
  if (!file) return;

  try {
    data = normalizeData(JSON.parse(await file.text()));
    saveData();
    resetTransactionForm();
    render();
  } catch {
    alert("Nao foi possivel importar esse arquivo.");
  } finally {
    elements.importInput.value = "";
  }
});

elements.transactionRows.addEventListener("click", (event) => {
  const editButton = event.target.closest("[data-edit-transaction]");
  const deleteButton = event.target.closest("[data-delete-transaction]");

  if (editButton) {
    startEditTransaction(editButton.dataset.editTransaction);
    return;
  }

  if (!deleteButton) return;
  if (!confirm("Excluir este lancamento?")) return;

  data.transactions = data.transactions.filter((item) => item.id !== deleteButton.dataset.deleteTransaction);
  saveData();
  render();
});

elements.accountsList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-delete-bank]");
  if (!button) return;

  const bank = data.banks.find((item) => item.id === button.dataset.deleteBank);
  if (!bank) return;

  const linkedTransactions = data.transactions.filter((item) => item.bankId === bank.id).length;
  const message = linkedTransactions
    ? `Excluir ${bank.name} e ${linkedTransactions} lancamento${linkedTransactions > 1 ? "s" : ""} vinculado${linkedTransactions > 1 ? "s" : ""}?`
    : `Excluir ${bank.name}?`;

  if (!confirm(message)) return;

  data.banks = data.banks.filter((item) => item.id !== bank.id);
  data.transactions = data.transactions.filter((item) => item.bankId !== bank.id);
  saveData();
  render();
});

elements.budgetList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-delete-budget]");
  if (!button) return;

  delete data.budgets[button.dataset.deleteBudget];
  saveData();
  render();
});

function createInitialData() {
  return {
    banks: [],
    transactions: [],
    budgets: {},
  };
}

function loadData() {
  const saved = localStorage.getItem(storageKey);
  const oldSaved = localStorage.getItem(oldStorageKey);

  try {
    if (saved) return normalizeData(JSON.parse(saved));
    if (oldSaved) return normalizeData(JSON.parse(oldSaved));
  } catch {
    return initialData;
  }

  return initialData;
}

function normalizeData(raw) {
  const banks = Array.isArray(raw.banks)
    ? raw.banks.map((bank) => ({
        id: bank.id || crypto.randomUUID(),
        name: bank.name || "Conta sem nome",
        type: bank.type || "Conta corrente",
        currency: bank.currency === "EUR" ? "EUR" : "BRL",
        initialBalance: Number(bank.initialBalance || 0),
        color: bank.color || "#1864ab",
      }))
    : [];

  const sourceTransactions = Array.isArray(raw.transactions) ? raw.transactions : Array.isArray(raw.expenses) ? raw.expenses : [];

  const transactions = sourceTransactions.map((item) => ({
    id: item.id || crypto.randomUUID(),
    type: item.type || "expense",
    status: item.status || "paid",
    bankId: item.bankId || banks[0]?.id || "",
    description: item.description || "Lancamento",
    category: item.category || "Outros",
    paymentMethod: item.paymentMethod || "Debito",
    amount: Number(item.amount || 0),
    date: item.date || todayIso(),
    note: item.note || "",
  }));

  return {
    banks,
    transactions,
    budgets: raw.budgets && typeof raw.budgets === "object" ? raw.budgets : {},
  };
}

function saveData() {
  localStorage.setItem(storageKey, JSON.stringify(data));
}

function render() {
  renderSelectors();
  const visibleTransactions = getVisibleTransactions();
  renderSummary();
  renderAccounts();
  renderBars(elements.categoryBars, groupExpensesBy(visibleTransactions, "category"), "#0f766e");
  renderBars(elements.bankBars, groupNetByBank(visibleTransactions), "#1864ab", true);
  renderBars(elements.paymentBars, groupExpensesBy(visibleTransactions, "paymentMethod"), "#6941c6");
  renderBudgets();
  renderTransactions(visibleTransactions);
}

function renderSelectors() {
  const currentTransactionBank = elements.transactionBank.value;
  const currentFilterBank = elements.filterBank.value;
  const currentInvoiceCardBank = elements.invoiceCardBank.value;
  const currentInvoicePayingBank = elements.invoicePayingBank.value;
  const currentTransferFromBank = elements.transferFromBank.value;
  const currentTransferToBank = elements.transferToBank.value;

  elements.transactionBank.innerHTML = data.banks
    .map((bank) => `<option value="${bank.id}">${escapeHtml(bank.name)} (${bank.currency || "BRL"})</option>`)
    .join("");

  elements.filterBank.innerHTML = [
    `<option value="all">Todos os bancos</option>`,
    ...data.banks.map((bank) => `<option value="${bank.id}">${escapeHtml(bank.name)} (${bank.currency || "BRL"})</option>`),
  ].join("");

  const creditCardBanks = data.banks.filter((bank) => bank.type.toLowerCase().includes("credito"));
  const invoiceCardOptions = (creditCardBanks.length ? creditCardBanks : data.banks)
    .map((bank) => `<option value="${bank.id}">${escapeHtml(bank.name)} (${bank.currency || "BRL"})</option>`)
    .join("");
  const invoicePayingOptions = data.banks
    .map((bank) => `<option value="${bank.id}">${escapeHtml(bank.name)} (${bank.currency || "BRL"})</option>`)
    .join("");

  elements.invoiceCardBank.innerHTML = invoiceCardOptions;
  elements.invoicePayingBank.innerHTML = invoicePayingOptions;
  elements.transferFromBank.innerHTML = invoicePayingOptions;
  elements.transferToBank.innerHTML = invoicePayingOptions;

  if (data.banks.some((bank) => bank.id === currentTransactionBank)) {
    elements.transactionBank.value = currentTransactionBank;
  }

  if (currentFilterBank === "all" || data.banks.some((bank) => bank.id === currentFilterBank)) {
    elements.filterBank.value = currentFilterBank || "all";
  }

  if (data.banks.some((bank) => bank.id === currentInvoiceCardBank)) {
    elements.invoiceCardBank.value = currentInvoiceCardBank;
  }

  if (data.banks.some((bank) => bank.id === currentInvoicePayingBank)) {
    elements.invoicePayingBank.value = currentInvoicePayingBank;
  }

  if (data.banks.some((bank) => bank.id === currentTransferFromBank)) {
    elements.transferFromBank.value = currentTransferFromBank;
  }

  if (data.banks.some((bank) => bank.id === currentTransferToBank)) {
    elements.transferToBank.value = currentTransferToBank;
  }

  elements.transactionBank.disabled = data.banks.length === 0;
  elements.invoiceCardBank.disabled = data.banks.length === 0;
  elements.invoicePayingBank.disabled = data.banks.length === 0;
  elements.transferFromBank.disabled = data.banks.length === 0;
  elements.transferToBank.disabled = data.banks.length === 0;
  updateInvoicePendingTotal();
}

function renderSummary() {
  const monthTransactions = data.transactions.filter(isCurrentMonth);
  const currencies = ["BRL", "EUR"];
  const formatTotals = (totals) => currencies
    .filter((currency) => totals[currency] !== undefined)
    .map((currency) => formatCurrency(totals[currency] || 0, currency))
    .join(" · ") || formatCurrency(0, "BRL");

  const balances = {};
  const incomes = {};
  const expenses = {};
  const pending = {};
  currencies.forEach((currency) => {
    const accounts = data.banks.filter((bank) => (bank.currency || "BRL") === currency);
    balances[currency] = accounts.reduce((total, bank) => total + getBankBalance(bank.id), 0);
    pending[currency] = accounts.reduce((total, bank) => total + getInvoicePendingTotal(bank.id), 0);
    incomes[currency] = sum(monthTransactions.filter((item) => item.type === "income" && getBankCurrency(item.bankId) === currency));
    expenses[currency] = sum(monthTransactions.filter((item) => item.type === "expense" && getBankCurrency(item.bankId) === currency));
  });

  elements.totalBRL.textContent = formatCurrency(balances.BRL, "BRL");
  elements.totalEUR.textContent = formatCurrency(balances.EUR, "EUR");
  elements.monthIncome.textContent = formatTotals(incomes);
  elements.monthExpense.textContent = formatTotals(expenses);
  elements.pendingTotal.textContent = formatTotals(pending);
}

function renderAccounts() {
  elements.accountsHint.textContent = data.banks.length
    ? `${data.banks.length} conta${data.banks.length > 1 ? "s" : ""}`
    : "Cadastre sua primeira conta";

  if (!data.banks.length) {
    elements.accountsList.innerHTML = `<p class="empty-state">Nenhuma conta cadastrada.</p>`;
    return;
  }

  elements.accountsList.innerHTML = data.banks
    .map((bank) => {
      const balance = getBankBalance(bank.id);
      const pending = getInvoicePendingTotal(bank.id);
      return `
        <article class="account-card" style="--account-color: ${bank.color}">
          <div class="account-card-header">
            <h3>${escapeHtml(bank.name)}</h3>
            <button class="danger-button icon-button" type="button" data-delete-bank="${bank.id}" title="Excluir banco">x</button>
          </div>
          <p>${escapeHtml(bank.type)}</p>
          <strong class="${balance < 0 ? "negative" : "positive"}">${formatCurrency(balance, bank.currency)}</strong>
          <small>${bank.currency === "EUR" ? "Euro (EUR)" : "Real brasileiro (BRL)"}</small>
          <small>Inicial: ${formatCurrency(bank.initialBalance || 0, bank.currency)}</small>
          <small class="${pending > 0 ? "negative" : ""}">Fatura pendente: ${formatCurrency(pending, bank.currency)}</small>
        </article>
      `;
    })
    .join("");
}

function renderBars(container, totals, fallbackColor, allowNegative = false) {
  const entries = Object.entries(totals).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));
  const max = Math.max(...entries.map(([, total]) => Math.abs(total)), 0);

  if (!entries.length) {
    container.innerHTML = `<p class="empty-state">Sem dados para exibir.</p>`;
    return;
  }

  container.innerHTML = entries
    .map(([label, total]) => {
      const bank = data.banks.find((item) => item.name === label);
      const width = max ? Math.max((Math.abs(total) / max) * 100, 4) : 0;
      const color = total < 0 && allowNegative ? "#b42318" : bank?.color || fallbackColor;
      return `
        <div class="bar-row">
          <div class="bar-meta">
            <strong>${escapeHtml(label)}</strong>
            <span>${formatCurrency(total, bank?.currency || currencyFromLabel(label))}</span>
          </div>
          <div class="bar-track">
            <div class="bar-fill" style="--bar-width: ${width}%; --bar-color: ${color}"></div>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderBudgets() {
  const entries = Object.entries(data.budgets);
  if (!entries.length) {
    elements.budgetList.innerHTML = `<p class="empty-state">Nenhum orcamento cadastrado.</p>`;
    return;
  }

  const monthExpenses = data.transactions.filter((item) => item.type === "expense" && isCurrentMonth(item));

  elements.budgetList.innerHTML = entries
    .map(([category, limit]) => {
      const spent = sum(monthExpenses.filter((item) => item.category === category));
      const percent = limit > 0 ? Math.min((spent / limit) * 100, 100) : 0;
      const exceeded = spent > limit;
      return `
        <div class="budget-item">
          <div class="bar-meta">
            <strong>${escapeHtml(category)}</strong>
            <span>${formatCurrency(spent)} / ${formatCurrency(limit)}</span>
          </div>
          <div class="bar-track">
            <div class="bar-fill" style="--bar-width: ${percent}%; --bar-color: ${exceeded ? "#b42318" : "#0f766e"}"></div>
          </div>
          <button class="danger-button compact" type="button" data-delete-budget="${escapeHtml(category)}">Excluir</button>
        </div>
      `;
    })
    .join("");
}

function renderTransactions(transactions) {
  elements.transactionCount.textContent = `${transactions.length} registro${transactions.length === 1 ? "" : "s"}`;

  if (!transactions.length) {
    elements.transactionRows.innerHTML = elements.emptyStateTemplate.innerHTML;
    return;
  }

  elements.transactionRows.innerHTML = [...transactions]
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((transaction) => {
      const bank = data.banks.find((item) => item.id === transaction.bankId);
      const amountClass = transaction.type === "income" ? "positive" : "negative";
      return `
        <article class="transaction-card">
          <div class="transaction-main">
            <div>
              <span class="date-label">${formatDate(transaction.date)}</span>
              <h3>${escapeHtml(transaction.description)}</h3>
              <p>${escapeHtml(bank?.name || "Conta removida")} · ${escapeHtml(transaction.category)}</p>
            </div>
            <strong class="${amountClass}">${transaction.type === "income" ? "+" : "-"} ${formatCurrency(transaction.amount, getBankCurrency(transaction.bankId))}</strong>
          </div>
          ${transaction.note ? `<small>${escapeHtml(transaction.note)}</small>` : ""}
          <div class="chip-row">
            <span class="pill ${transaction.type === "income" ? "income-pill" : "expense-pill"}">${transaction.type === "income" ? "Receita" : "Despesa"}</span>
            <span class="pill payment-pill">${escapeHtml(transaction.paymentMethod)}</span>
            <span class="pill status-pill">${statusLabel(transaction.status)}</span>
          </div>
          <div class="row-actions">
            <button class="ghost-button compact" type="button" data-edit-transaction="${transaction.id}">Editar</button>
            <button class="danger-button compact" type="button" data-delete-transaction="${transaction.id}">Excluir</button>
          </div>
        </article>
      `;
    })
    .join("");
}

function legacyTableRowTemplate(transaction, bank, amountClass) {
  return `
        <tr>
          <td>${formatDate(transaction.date)}</td>
          <td>
            <strong>${escapeHtml(transaction.description)}</strong>
            ${transaction.note ? `<small>${escapeHtml(transaction.note)}</small>` : ""}
          </td>
          <td><span class="pill ${transaction.type === "income" ? "income-pill" : "expense-pill"}">${transaction.type === "income" ? "Receita" : "Despesa"}</span></td>
          <td>${escapeHtml(bank?.name || "Conta removida")}</td>
          <td><span class="pill">${escapeHtml(transaction.category)}</span></td>
          <td><span class="pill payment-pill">${escapeHtml(transaction.paymentMethod)}</span></td>
          <td><span class="pill status-pill">${statusLabel(transaction.status)}</span></td>
          <td class="amount ${amountClass}">${transaction.type === "income" ? "+" : "-"} ${formatCurrency(transaction.amount, getBankCurrency(transaction.bankId))}</td>
          <td class="row-actions">
            <button class="ghost-button compact" type="button" data-edit-transaction="${transaction.id}">Editar</button>
            <button class="danger-button compact" type="button" data-delete-transaction="${transaction.id}">Excluir</button>
          </td>
        </tr>
      `;
}

function getVisibleTransactions() {
  const search = elements.searchInput.value.trim().toLowerCase();
  const bankFilter = elements.filterBank.value;
  const typeFilter = elements.filterType.value;
  const paymentFilter = elements.filterPayment.value;
  const statusFilter = elements.filterStatus.value;
  const period = elements.filterPeriod.value;
  const today = new Date();

  return data.transactions.filter((transaction) => {
    const bank = data.banks.find((item) => item.id === transaction.bankId);
    const text = `${transaction.description} ${transaction.category} ${transaction.paymentMethod} ${transaction.status} ${transaction.note} ${bank?.name || ""}`.toLowerCase();
    const transactionDate = new Date(`${transaction.date}T00:00:00`);

    const matchesSearch = !search || text.includes(search);
    const matchesBank = bankFilter === "all" || transaction.bankId === bankFilter;
    const matchesType = typeFilter === "all" || transaction.type === typeFilter;
    const matchesPayment = paymentFilter === "all" || transaction.paymentMethod === paymentFilter;
    const matchesStatus = statusFilter === "all" || transaction.status === statusFilter;
    const matchesPeriod =
      period === "all" ||
      (period === "month" && sameMonth(transactionDate, today)) ||
      (period === "year" && transactionDate.getFullYear() === today.getFullYear()) ||
      (period === "last30" && today - transactionDate <= 30 * 24 * 60 * 60 * 1000);

    return matchesSearch && matchesBank && matchesType && matchesPayment && matchesStatus && matchesPeriod;
  });
}

function startEditTransaction(id) {
  const transaction = data.transactions.find((item) => item.id === id);
  if (!transaction) return;

  elements.transactionId.value = transaction.id;
  elements.transactionType.value = transaction.type;
  syncTransactionTypeButtons();
  elements.transactionStatus.value = transaction.status;
  elements.transactionDescription.value = transaction.description;
  elements.transactionBank.value = transaction.bankId;
  elements.transactionAmount.value = transaction.amount;
  elements.transactionDate.value = transaction.date;
  elements.transactionCategory.value = transaction.category;
  elements.transactionPaymentMethod.value = transaction.paymentMethod;
  elements.transactionNote.value = transaction.note || "";
  syncTransactionFields();
  elements.transactionFormTitle.textContent = "Editar lancamento";
  elements.saveTransactionButton.textContent = "Salvar alteracoes";
  elements.cancelEditButton.classList.remove("hidden");
  showScreen("new");
  showActionPanel("transaction");
  elements.transactionDescription.focus();
}

function resetTransactionForm() {
  elements.transactionForm.reset();
  elements.transactionId.value = "";
  elements.transactionDate.value = todayIso();
  elements.transactionType.value = "expense";
  syncTransactionTypeButtons();
  elements.transactionFormTitle.textContent = "Novo lancamento";
  elements.saveTransactionButton.textContent = "Registrar lancamento";
  elements.cancelEditButton.classList.add("hidden");
  syncTransactionFields();
}

function syncTransactionFields() {
  if (elements.transactionType.value === "income") {
    elements.transactionStatus.value = "paid";
    elements.transactionPaymentMethod.value = "Pix";
    elements.transactionStatusField.classList.add("hidden");
    elements.transactionPaymentField.classList.add("hidden");
    return;
  }

  elements.transactionStatusField.classList.remove("hidden");
  elements.transactionPaymentField.classList.remove("hidden");

  if (!elements.transactionId.value) {
    elements.transactionStatus.value = elements.transactionPaymentMethod.value === "Credito" ? "pending" : "paid";
  }
}

function syncTransactionTypeButtons() {
  elements.typeButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.typeChoice === elements.transactionType.value);
  });
}

function resetInvoicePaymentForm() {
  elements.invoicePaymentForm.reset();
  elements.invoiceDate.value = todayIso();
  updateInvoicePendingTotal();
}

function resetTransferForm() {
  elements.transferForm.reset();
  elements.transferDate.value = todayIso();
}

function setSelectedBankColor(color) {
  elements.bankColor.value = color;
  elements.bankColorOptions.forEach((button) => {
    button.classList.toggle("selected", button.dataset.color === color);
  });
}

function showScreen(screenName) {
  elements.screens.forEach((screen) => {
    screen.classList.toggle("active", screen.dataset.screen === screenName);
  });

  elements.tabButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.target === screenName);
  });

  elements.screenTitle.textContent = screenTitles[screenName] || "Banco";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function showActionPanel(panelName) {
  elements.actionButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.actionTarget === panelName);
  });

  elements.actionPanels.forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.actionPanel === panelName);
  });
}

function getBankBalance(bankId) {
  const bank = data.banks.find((item) => item.id === bankId);
  const initialBalance = Number(bank?.initialBalance || 0);

  return data.transactions
    .filter((item) => item.bankId === bankId && item.status === "paid")
    .reduce((total, item) => total + signedAmount(item), initialBalance);
}

function getPendingInvoiceTransactions(bankId) {
  return data.transactions
    .filter((item) => item.bankId === bankId && item.type === "expense" && item.status !== "paid" && item.paymentMethod === "Credito")
    .sort((a, b) => a.date.localeCompare(b.date));
}

function getInvoicePendingTotal(bankId) {
  return sum(getPendingInvoiceTransactions(bankId));
}

function updateInvoicePendingTotal() {
  if (!elements.invoicePendingTotal) return;
  elements.invoicePendingTotal.textContent = formatCurrency(getInvoicePendingTotal(elements.invoiceCardBank.value), getBankCurrency(elements.invoiceCardBank.value));
}

function applyInvoicePayment(cardBankId, paymentAmount, status, groupId) {
  if (status !== "paid") return;

  let remainingPayment = paymentAmount;
  const pendingTransactions = getPendingInvoiceTransactions(cardBankId);

  pendingTransactions.forEach((transaction) => {
    if (remainingPayment <= 0) return;

    const transactionAmount = Number(transaction.amount || 0);

    if (remainingPayment >= transactionAmount) {
      transaction.status = "paid";
      transaction.note = appendNote(transaction.note, `Pago na fatura ${groupId.slice(0, 8)}`);
      remainingPayment -= transactionAmount;
      return;
    }

    const paidAmount = remainingPayment;
    const pendingAmount = transactionAmount - paidAmount;

    transaction.amount = Number(pendingAmount.toFixed(2));
    transaction.note = appendNote(transaction.note, `Restante apos pagamento parcial`);

    data.transactions.push({
      ...transaction,
      id: crypto.randomUUID(),
      groupId,
      status: "paid",
      amount: Number(paidAmount.toFixed(2)),
      note: appendNote(transaction.note, `Parte paga na fatura ${groupId.slice(0, 8)}`),
    });

    remainingPayment = 0;
  });
}

function appendNote(currentNote, extraNote) {
  return currentNote ? `${currentNote} | ${extraNote}` : extraNote;
}

function groupExpensesBy(transactions, key) {
  return transactions
    .filter((item) => item.type === "expense")
    .reduce((totals, item) => {
      const currency = getBankCurrency(item.bankId);
      const label = `${item[key] || "Nao informado"} · ${currency}`;
      totals[label] = (totals[label] || 0) + Number(item.amount);
      return totals;
    }, {});
}

function groupNetByBank(transactions) {
  return transactions.reduce((totals, item) => {
    const bank = data.banks.find((bankItem) => bankItem.id === item.bankId);
    const name = bank?.name || "Conta removida";
    totals[name] = (totals[name] || 0) + signedAmount(item);
    return totals;
  }, {});
}

function signedAmount(transaction) {
  return Number(transaction.amount || 0) * (transaction.type === "income" ? 1 : -1);
}

function sum(transactions) {
  return transactions.reduce((total, item) => total + Number(item.amount || 0), 0);
}

function isCurrentMonth(transaction) {
  return sameMonth(new Date(`${transaction.date}T00:00:00`), new Date());
}

function sameMonth(date, reference) {
  return date.getMonth() === reference.getMonth() && date.getFullYear() === reference.getFullYear();
}

function statusLabel(status) {
  const labels = {
    paid: "Pago",
    pending: "Pendente",
    scheduled: "Agendado",
  };
  return labels[status] || "Pago";
}

function getBankCurrency(bankId) {
  return data.banks.find((bank) => bank.id === bankId)?.currency || "BRL";
}

function currencyFromLabel(label) {
  return String(label).endsWith("EUR") ? "EUR" : "BRL";
}

function formatCurrency(value, currency = "BRL") {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: currency === "EUR" ? "EUR" : "BRL",
  }).format(value);
}

function formatDate(value) {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" }).format(new Date(`${value}T00:00:00Z`));
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

render();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  });
}
